This demo uses the logistic regression

P = Alzheimers H = No Alzheimers

Make sure to run py model.py in the terminal to set the model, then run py app.py to start the GUI

If you are having trouble getting both classes to show try:

For H:

total_time25 = 68020	pressure_var25 = 141043.2693 (scroll to end of dropdown to select)

For P: 

If you put random values most likley it will result in p


total_time25 = 74605	pressure_var25 = 152045.4446 (scroll to end of dropdown to select)



